/* ----------------- CONFIG ----------------- */
const GEOJSON_URL  = 'assets/data/arbres.geojson';
const MAPBOX_TOKEN = 'pk.eyJ1IjoiY2FpbGxvdXhlbG1hcmxvdSIsImEiOiJjbWEzb2l5dmUyMzFtMmtzZDNjcmt0MDJ1In0.yODitvwE981IY0VGPm320w';
const MAP_CENTER   = [3.29, 49.85];   // Saint-Quentin

/* -------------- INITIALISATION ------------ */
mapboxgl.accessToken = MAPBOX_TOKEN;
let map;                   // instance Mapbox
const markerDict = {};     // id_arbre → marker

document.addEventListener('DOMContentLoaded', async () => {
  map = new mapboxgl.Map({
    container: 'map',
    style: 'mapbox://styles/mapbox/streets-v12',
    center: MAP_CENTER,
    zoom: 12
  });

  /* --- Chargement GeoJSON --- */
  try {
    const geojson = await fetch(GEOJSON_URL).then(r => r.json());
    console.log(`Chargé ${geojson.features.length} arbres`);

    populateTable(geojson.features);
    plotMarkers(geojson.features);
  } catch (err) {
    console.error('Erreur de chargement GeoJSON :', err);
    alert('Impossible de charger les données des arbres.');
  }
});

/* ------------ TABLEAU HTML ---------------- */
function populateTable(features) {
  const tbody = document.querySelector('#tree-table tbody');
  tbody.innerHTML = '';

  features.forEach((f, idx) => {
    const p  = f.properties ?? {};
    const id = p.id_arbre ?? idx;

    const tr = document.createElement('tr');
    tr.dataset.id = id;
    tr.innerHTML = `
      <td>${id}</td>
      <td>${p.clc_quartier || ''}</td>
      <td>${p.haut_tot     || ''}</td>
      <td>${p.tronc_diam   || ''}</td>
      <td>${f.geometry.coordinates[1].toFixed(5)}, ${f.geometry.coordinates[0].toFixed(5)}</td>
    `;
    tbody.appendChild(tr);

    /* clic → zoom + popup */
    tr.addEventListener('click', () => {
      const m = markerDict[id];
      if (m) {
        map.flyTo({ center: m.getLngLat(), zoom: 15, essential: true });
        m.togglePopup();
      }
      highlightRow(id);
    });
  });
}

/* ------------- MARQUEURS ------------------ */
function plotMarkers(features) {
  features.forEach((f, idx) => {
    const [lon, lat] = f.geometry.coordinates;
    const p  = f.properties ?? {};
    const id = p.id_arbre ?? idx;

    const marker = new mapboxgl.Marker({ color: '#2e7d32' })
      .setLngLat([lon, lat])
      .setPopup(new mapboxgl.Popup().setHTML(`
        <strong>${p.clc_secteur || 'Secteur ?'}</strong><br>
        Quartier : ${p.clc_quartier || '—'}<br>
        Hauteur : ${p.haut_tot || '?'} m
      `))
      .addTo(map);

    markerDict[id] = marker;

    /* survol marker → surligne ligne */
    marker.getElement().addEventListener('mouseenter', () => highlightRow(id));
    marker.getElement().addEventListener('mouseleave', () => highlightRow(null));
  });
}

/* ------------- HIGHLIGHT ------------------ */
function highlightRow(id) {
  document.querySelectorAll('#tree-table tbody tr').forEach(tr => {
    tr.classList.toggle('active', id && tr.dataset.id == id);
  });
}
