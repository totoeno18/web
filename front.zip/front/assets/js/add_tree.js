document.addEventListener('DOMContentLoaded',()=>{
  const f=document.getElementById('add-tree-form');const msg=document.getElementById('msg');
  f.addEventListener('submit',async e=>{
    e.preventDefault();const data=Object.fromEntries(new FormData(f));
    try{await apiFetch('trees.php',{method:'POST',body:JSON.stringify(data)});
      msg.textContent='Arbre ajouté !';f.reset();
    }catch(err){msg.textContent='Erreur : '+err.message;msg.style.color='red';}
  });
});